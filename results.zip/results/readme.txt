Folder contains results for all experiments and spreadsheet with some important summary statistics.
Each sub-folder contains screenshots of each run at year 5 and 500, raw data as output_*.csv, and analysis spreadsheet as analysis_*.xlsx.

Setting parameters that remain constant throughout runs are:
Starting households:		20
Starting workers:		5
Starting grain:			2000
Min ambition:			0.5
Min competency:			0.5
Generational variation:		0.5
Knowledge radius:		10
Distance cost:			10
Fallow limit:			5
Population growth rate:		0.1

Setting parameters changed across runs:
Max exploration:
	Low:	0.55
	High:	0.95
Exploration reduction per year:
	None:	0
	Low:	0.01
	High:	0.04